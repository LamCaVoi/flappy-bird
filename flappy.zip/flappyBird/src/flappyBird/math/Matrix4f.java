package flappyBird.math;

import java.util.Scanner;
import static java.lang.Math.*;

public class Matrix4f {
	Scanner sc = new Scanner(System.in);
	private static int SIZE = 16;
	public float[] matrix = new float[SIZE];
	
	public static Matrix4f identity() {
		Matrix4f res = new Matrix4f();
		
		for (int i = 0; i < SIZE; i++) {
			if (i - (i/4)*4 == i/4)
				res.matrix[i] = 1;
			else
				res.matrix[i] = 0.0f;
		}
		
		return res;
	}
	
	public Matrix4f multiply(Matrix4f matrix) {
		Matrix4f res = new Matrix4f();
		
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				int sum = 0;
				for (int k = 0; k < 4; k++) {
					sum += this.matrix[k + i*4] * matrix.matrix[j + k*4];
					
				}
				res.matrix[j + i * 4] = sum; 
			}
		}
		
		return res;
		
	}
	
	public Matrix4f translate(Vector3f vector) {
		Matrix4f res = identity();
		
		res.matrix[0 + 3 * 4] = vector.x;
		res.matrix[1 + 3 * 4] = vector.y;
		res.matrix[2 + 3 * 4] = vector.z;
		
		
		return res;
		
	}
	
	public Matrix4f rotate(float angle) {
		Matrix4f res = identity();

		angle = (float) toRadians(angle);
		float sin = (float) sin(angle);
		float cos = (float) cos(angle);
		
		res.matrix[0 + 0 * 4] = cos;
		res.matrix[1 + 0 * 4] = sin;
		
		res.matrix[0 + 1 * 4] = -sin;
		res.matrix[1 + 1 * 4] = cos;
	
		
		return res;
		
	}	
	
	public static Matrix4f orthogarphic(float left, float right, float top, float bottom, float near, float far) {
		Matrix4f res = new Matrix4f();
		
		res.matrix[0 + 0 * 4] = 2/(right - left);
		
		res.matrix[1 + 1 * 4] = 2/(top - bottom);
		
		res.matrix[2 + 2 * 4] = 2/(near - far);
		
		res.matrix[3 + 3 * 4] = 1;
		
		res.matrix[3 + 2 * 4] = (near + far) / (far - near);
		
		res.matrix[3 + 1 * 4] = (bottom + top) / (bottom - top);
		
		res.matrix[0 + 0 * 4] = (left + right) / (left - right);
		
		return res;
	}
	
	
	
	public void input() {
		System.out.println("Start inputting");
		for (int i = 0; i < SIZE; i++) {
			matrix[i] = sc.nextFloat();
			
		}
	}
	
	public void print() {
		System.out.println("Start outputting");
		for (int i = 0; i < SIZE; i++) {
			System.out.print(matrix[i] + " "); 
			
		}
	}
}
