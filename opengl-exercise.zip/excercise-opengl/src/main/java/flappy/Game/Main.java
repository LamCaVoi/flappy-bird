package flappy.Game;

import flappy.Engine.*;
 
public class Main {
 
    public static void main(String[] args) {
        try {
            boolean vSync = true;
            IAppLogic gameLogic = new Flappy();
            Engine engine = new Engine("Flappy Bird!!!", 1280, 720, vSync, gameLogic);
            engine.run();
        } catch (Exception excp) {
            excp.printStackTrace();
            System.exit(-1);
        }
    }
}