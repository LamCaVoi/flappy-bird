package flappy.Engine;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryStack.*;
import static org.lwjgl.system.MemoryUtil.*;

import java.nio.IntBuffer;

import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL;
import org.lwjgl.system.MemoryStack;

public class Window {

	private String title;
	private int width;
	private int height;
	private long window;
	private boolean vSync;
	private boolean resized;

	public Window(String title, int width, int height, boolean vSync) {
		super();
		this.title = title;
		this.width = width;
		this.height = height;
		this.vSync = vSync;
		this.resized = false;
	}

	public void init() {

		glfwSetErrorCallback(GLFWErrorCallback.createPrint(System.err).set());

		if (!glfwInit()) {
			throw new IllegalStateException("Failed to initialize glfw!!!");

		}

		glfwDefaultWindowHints();
		glfwWindowHint(GLFW_VISIBLE, GL_FALSE);
		glfwWindowHint(GLFW_RESIZABLE, GL_TRUE);
		glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
		glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
		glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
		glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

		window = glfwCreateWindow(1280, 720, "Flappy Bird <(*)", NULL, NULL);

		if (window == 0) {
			throw new IllegalStateException("Failed to initialize the window !!!");

		}

		glfwSetKeyCallback(window, (window, key, scancode, action, mods) -> {
			if (key == GLFW_KEY_SPACE && action == GLFW_RELEASE)
				glfwSetWindowShouldClose(window, true);

		});

		glfwSetFramebufferSizeCallback(window, (window, width, height) -> {
			this.width = width;
			this.height = height;
			resized = true;

		});

		try (MemoryStack stack = stackPush()) {
			IntBuffer pWidth = stack.mallocInt(1);
			IntBuffer pHeight = stack.mallocInt(1);

			glfwGetWindowSize(window, pWidth, pHeight);

			GLFWVidMode vidMode = glfwGetVideoMode(glfwGetPrimaryMonitor());

			glfwSetWindowPos(window, (vidMode.width() - pWidth.get()) / 2, (vidMode.height() - pHeight.get()) / 2);

		}

		glfwMakeContextCurrent(window);

		if (vSync) {
			glfwSwapInterval(1);

		}

		glfwShowWindow(window);

		GL.createCapabilities();

		glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	}
	
	
	
	public void setClearColor(float red, float green, float blue, float alpha) {
		glClearColor(red, green, blue, alpha);
		
	}
	
    public boolean isKeyPressed(int keyCode) {
        return glfwGetKey(window, keyCode) == GLFW_PRESS;
    }

    public boolean windowShouldClose() {
        return glfwWindowShouldClose(window);
    }

	public String getTitle() {
		return title;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public boolean isvSync() {
		return vSync;
	}

	public void setvSync(boolean vSync) {
		this.vSync = vSync;
	}

	public boolean isResized() {
		return resized;
	}

	public void setResized(boolean resized) {
		this.resized = resized;
	}
	
    public void update() {
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    
    public void cleanUp() {
    	
    	glfwFreeCallbacks(window);
    	glfwDestroyWindow(window);
    	glfwTerminate();
    }

	private void glfwFreeCallbacks(long window2) {
		glfwSetKeyCallback(window2, null);
		glfwSetFramebufferSizeCallback(window2, null);
		glfwSetCursorPosCallback(window2, null);
		glfwSetMouseButtonCallback(window2, null);
		
		GLFWErrorCallback callBack = glfwSetErrorCallback(null);
		if(callBack != null) {
			callBack.free();
		}
	}
    
}














